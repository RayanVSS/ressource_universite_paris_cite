package fr.yunes.tp2;

import java.io.Serializable;

public record Identity(String firstName, String lastName) implements Serializable {
	@Override
	public String toString() {
		return firstName+" "+lastName;
	}
	
}
