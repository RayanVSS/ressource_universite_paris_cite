package fr.yunes.tp2;

import java.util.Objects;
import java.util.Random;

public enum Position {
	MANAGER("Manager"),
	ENGINEER("Engineer"),
	DIRECTOR("Director"),
	ACCOUNTANT("Accountant"); 
	private String name;
	private Position(String name) {
		Objects.requireNonNull(name);
		this.name = name;
	}
	public String toString() {
		return name;
	}
	private static Random r = new Random(1);
	public static Position random() {
		Position [] values = Position.values();
		return values[r.nextInt(values.length)];
	}
}
