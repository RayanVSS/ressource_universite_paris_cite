import java.util.List;
import java.util.Random;

public class Main {
    static BoiteMessages boite = new BoiteMessages();
    static SectionsCritiques sectionsCritiques = new SectionsCritiques();

    public static void main(String[] args) {
        Messages messages1 = new Messages(new String[]{"In", "Sunt", "dicere", "cuius",
                "homines", "notas", "rebus", "praecurrit", "dicere", "omnis", "praecurrit",
                "enim", "est", "cuius", "parandis"});

        ProducerThread w1 = new ProducerThread(sectionsCritiques, messages1);

        Messages messages2 = new Messages(new String[]{"W", "Szczebrzyszynie", "chrzaszcz",
                "brzmi", "trzcinie", "slynie", "wol", "pyta"});
        ProducerThread w2 = new ProducerThread(sectionsCritiques, messages2 );

        ConsumerThread r1 = new ConsumerThread(sectionsCritiques, "r1");
        ConsumerThread r2 = new ConsumerThread(sectionsCritiques, "r2");
        ConsumerThread r3 = new ConsumerThread(sectionsCritiques, "r3");
        ConsumerThread r4 = new ConsumerThread(sectionsCritiques, "r4");

        List<Thread> listThread = List.of(w1, w2, r1, r2, r3, r4);
        for (Thread t : listThread) t.start();
    }

    static class BoiteMessages {
        private String message;
        public String getMessage() {
            return message;
        }
        public void setMessage(String message) {
            this.message = message;
        }
    }

    static class Messages {
        private String[] msg;
        private Random random = new Random(System.currentTimeMillis());
        public Messages(String[] msg) {
            this.msg = msg;
        }
        public String getNewMessage() {
            return msg[random.nextInt(msg.length)];
        }
    }

    static class ProducerThread extends Thread {
        private Messages m;
        private SectionsCritiques sectionsCritiques;

        public ProducerThread(SectionsCritiques sectionsCritiques, Messages m) {
            this.sectionsCritiques = sectionsCritiques;
            this.m=m;
        }

        @Override
        public void run() {
            super.run();
            while (true) {
                sectionsCritiques.writeSection(() -> {
                            try { Thread.sleep(50);
                            } catch (InterruptedException e) { return; };
                            boite.setMessage(m.getNewMessage());
                        }
                );
                if (isInterrupted())  return;
            }
        }
    }

    static class ConsumerThread extends Thread {
        private SectionsCritiques sectionCritiques;

        public ConsumerThread(SectionsCritiques sectionsCritiques, String name) {
            super(name);
            this.sectionCritiques = sectionsCritiques;
            sectionsCritiques.registerReader(this, true);
        }

        @Override
        public void run() {
            super.run();
            while (true) {
                sectionCritiques.readSection(() -> {
                    try {
                        Thread.sleep(100);
                    } catch (InterruptedException e) { return; };
                    System.out.println(getName() + " " + boite.getMessage());
                });

                if (isInterrupted())   return;
            }
        }
    }
}
