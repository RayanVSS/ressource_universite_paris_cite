import java.util.Scanner;

public final class Producer {
    private long v = 0;
    private final Thread thread = new Thread(this::produce);
    public Thread getThread() { return thread; }
    private void produce() {
        while(true) { v++; }
    }
    public synchronized long getValue() { return v; }
}

final class Main {
    public static void main(String[] args) {
        // Démarrage du thread producteur
        Producer p = new Producer();
        p.getThread().start();
        // Lecture des valeurs produites
        try (var scanner = new Scanner(System.in)) {
            while (!scanner.nextLine().equals("q"))
                System.out.println("main = " + p.getValue());
        }
        // Interruption du thread producteur
        Thread.State state = p.getThread().getState();
        System.out.println( "state before interrupt " + state.name());
        p.getThread().interrupt();
        do {
            state = p.getThread().getState();
            System.out.println(state.name());
        }
        while (p.getThread().isInterrupted() && state != Thread.State.TERMINATED);
    }
}
