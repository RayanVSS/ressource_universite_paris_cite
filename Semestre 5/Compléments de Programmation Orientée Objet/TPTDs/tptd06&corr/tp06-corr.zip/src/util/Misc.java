package util;

import java.util.Iterator;
import java.util.function.BiConsumer;
import java.util.function.Consumer;

public class Misc {

	public static <T> void forEachIndexed(Iterable<T> elts, BiConsumer<Integer, T> toDo) {
		Iterator<T> it = elts.iterator();
		int i = 0;
		while (it.hasNext()) {
			toDo.accept(i++, it.next());
		}
	}

	public static void repeat(int times, Consumer<Integer> toDo) {
		for (int i = 0; i < times; i++)
			toDo.accept(i);
	}

	public static void repeat(int times, Runnable toDo) {
		for (int i = 0; i < times; i++)
			toDo.run();
	}
}
