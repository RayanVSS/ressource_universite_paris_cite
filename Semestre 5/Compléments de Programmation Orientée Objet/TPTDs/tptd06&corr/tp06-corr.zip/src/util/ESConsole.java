package util;

import java.util.Scanner;

public class ESConsole {
	private static final Scanner sc = new Scanner(System.in);

	public static int getBoundedInt(int min, int max) {
		out(String.format("(attendu : entier entre %d et %d)", min, max));
		while (true) {
			try {
				int val = Integer.parseInt(in());
				if (val >= min && val <= max)
					return val;
			} catch (NumberFormatException e) {
			}
			out("Ce n'est pas un entier entre " + min + " et " + max + ". Réessayez.");
		}
	}

	public static String in() {
		return sc.nextLine();
	}

	public static void out(String s) {
		System.out.println(s);
	}
}
