package cartes;

import java.awt.Color;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

public record CarteNormale(Valeur valeur, Enseigne enseigne) implements Carte {

    public enum Enseigne {
        CARREAU(Color.RED), COEUR(Color.RED), PIQUE(Color.BLACK), TREFLE(Color.BLACK);

        private final Color vraieCouleur;

        private Enseigne(Color vraieCouleur) {
            this.vraieCouleur = vraieCouleur;
        }

        public Color getVraieCouleur() {
            return vraieCouleur;
        }
    }

    public enum Valeur {
        AS, CINQ, DAME, DEUX, DIX, HUIT, NEUF, QUATRE, ROI, SEPT, SIX, TROIS, VALET;

        public boolean estFigure() {
            switch (this) {
                case VALET:
                case DAME:
                case ROI:
                    return true;
                default:
                    return false;
            }
        }
    }

    public boolean estFigure() {
        return valeur.estFigure();
    }

    @Override
    public String toString() {
        return valeur + " de " + enseigne;
    }

    public int getValeurNumerique() {
        return valeur.ordinal();
    }

    public Color getVraieCouleur() {
        return enseigne.getVraieCouleur();
    }

    public static List<CarteNormale> nouveauJeu52() {
        List<CarteNormale> jeu = new LinkedList<>();
        for (Enseigne c : Enseigne.values())
            for (Valeur v : Valeur.values())
                jeu.add(new CarteNormale(v, c));
        return Collections.unmodifiableList(jeu);
    }
}