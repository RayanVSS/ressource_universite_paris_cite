package cartes;

import java.util.Arrays;
import java.util.List;

public record Joker(DessinJoker dessin) implements Carte {

	public enum DessinJoker {
		DESSIN1, DESSIN2
	}

	public static List<Joker> nouvellePaire() {
		return Arrays.asList(new Joker[] { new Joker(DessinJoker.DESSIN1), new Joker(DessinJoker.DESSIN2) });
	}

	public Joker(DessinJoker dessin) {
		this.dessin = dessin;
	}
}
