package cartes;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

public sealed interface Carte permits cartes.CarteNormale,  cartes.Joker {

	public static List<Carte> nouveauJeu54() {
		List<Carte> jeu = new LinkedList<>();
		jeu.addAll(CarteNormale.nouveauJeu52());
		jeu.addAll(Joker.nouvellePaire());
		return Collections.unmodifiableList(jeu);
	}

}
