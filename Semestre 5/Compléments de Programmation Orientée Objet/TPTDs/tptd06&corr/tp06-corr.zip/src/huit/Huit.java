package huit;

import static util.ESConsole.getBoundedInt;
import static util.ESConsole.out;
import static util.Misc.repeat;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;

import cartes.CarteNormale;

public class Huit {

	public static void main(String args[]) {
		out("Nombre de joueurs ?");
		(new Huit(getBoundedInt(2, 4))).run();
	}
	// variables de jeu
	public int curPlayer;
	public final List<Joueur> joueurs;

	public int penaliteAccumulee;
	// caractéristiques fixes d'une partie
	public final LinkedList<CarteNormale> pioche;
	public CarteNormale.Enseigne prochaineEnseigne;

	public final LinkedList<CarteNormale> talon;

	private Huit(int nbPlayers) {
		pioche = new LinkedList<>(CarteNormale.nouveauJeu52());
		talon = pioche; // astuce : dans le huit américain joué avec des cartes
						// physiques, on est obligé de retourner le talon quand
						// la pioche est vide... pour simuler une file. Le mieux
						// en Java, c'est d'utiliser directement un Deque (comme
						// LinkedList)
		Collections.shuffle(pioche);
		int handSize;
		switch (nbPlayers) {
		case 2:
			handSize = 10;
			break;
		case 3:
			handSize = 8;
			break;
		default:
			handSize = 6;
		}

		// création des joueurs et distribution des cartes
		joueurs = new ArrayList<>(nbPlayers);
		repeat(nbPlayers, i -> joueurs.add(new JoueurHumainTexte(this, handSize, "Joueur " + i)));
	}

	private void appliqueEffets(CarteNormale carte) {
		prochaineEnseigne = carte.enseigne();
		if (carte.valeur() != CarteNormale.Valeur.DEUX) {
			repeat(penaliteAccumulee, () -> joueurs.get(curPlayer).pioche());
			penaliteAccumulee = 0;
		}
		switch (carte.valeur()) {
		case DIX ->
			curPlayer--;
		case DEUX ->
			penaliteAccumulee += 2;
		case HUIT ->
			prochaineEnseigne = joueurs.get(curPlayer).choisis("Nouvelle enseigne ?",
					Arrays.asList(CarteNormale.Enseigne.values()));
		default -> {}
		}
	}

	public boolean peutJouer(CarteNormale carte) {
		if (talon.peek().valeur() == carte.valeur())
			return true;
		if (prochaineEnseigne == carte.enseigne())
			return true;
		if (carte.valeur() == CarteNormale.Valeur.HUIT)
			return true;
		return false;
	}

	public void run() {
		talon.push(pioche.removeLast());
		prochaineEnseigne = talon.peek().enseigne();
		Joueur joueurCourant;
		while (true) {
			joueurCourant = (joueurs.get(curPlayer));
			joueurCourant.rafraichisUI();

			Optional<CarteNormale> choix = joueurCourant.joueCarte();
			if (choix.isPresent()) {
				appliqueEffets(choix.get());
			}
			if (joueurCourant.nbCartes() <= 0)
				break;
			curPlayer = (curPlayer + 1) % joueurs.size();
		}

		out("Vainqueur : " + joueurCourant.nom);

	}
}
