package huit;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;

import cartes.CarteNormale;

public abstract class Joueur {
	protected final List<CarteNormale> hand;
	protected final Huit jeu;
	public final String nom;

	public Joueur(Huit jeu, int handSize, String nom) {
		this.jeu = jeu;
		this.nom = nom;
		this.hand = new LinkedList<>();
		for (int j = 0; j < handSize; j++)
			pioche();
	}

	public <T> T choisis(List<T> listeChoix) {
		return choisis("Faites un choix :\n", listeChoix);
	}

	abstract public <T> T choisis(String message, List<T> values);

	public Optional<CarteNormale> joueCarte() {
		List<CarteNormale> cartesJouables = new ArrayList<>(hand.size());
		for (CarteNormale carte : hand)
			if (jeu.peutJouer(carte))
				cartesJouables.add(carte);
		if (cartesJouables.isEmpty()) {
			out("Vous n'avez pas de carte jouable, vous piochez !");
			pioche();
			return Optional.empty();
		}
		CarteNormale choix = choisis("Quelle carte voulez-vous jouer ?", cartesJouables);
		hand.remove(choix);
		jeu.talon.push(choix);
		return Optional.of(choix);
	}

	public int nbCartes() {
		return hand.size();
	}

	public abstract void out(String message);

	public CarteNormale pioche() {
		CarteNormale carte = jeu.pioche.removeLast();
		hand.add(carte);
		return carte;
	}

	abstract public void rafraichisUI();
}
