package huit;

import static util.ESConsole.getBoundedInt;

import java.util.List;

import util.ESConsole;

public class JoueurHumainTexte extends Joueur {

	public JoueurHumainTexte(Huit jeu, int handSize, String nom) {
		super(jeu, handSize, nom);
	}

	@Override
	public <T> T choisis(String message, List<T> listeChoix) {
		for (int i = 0; i < listeChoix.size(); i++)
			message += String.format("\n%d -> %s", i + 1, listeChoix.get(i));
		out(message);
		return listeChoix.get(getBoundedInt(1, listeChoix.size()) - 1);
	}

	@Override
	public void out(String message) {
		ESConsole.out(nom + " > " + message);
	}

	@Override
	public void rafraichisUI() {
		out("Votre main :\n" + hand);
		for (Joueur j : jeu.joueurs)
			if (j != JoueurHumainTexte.this)
				out(j.nom + "  : " + j.nbCartes() + " cartes");
		out("Dernière carte jouée :" + jeu.talon.peek());
		out("Couleur attendue : " + jeu.prochaineEnseigne);
	}

}
