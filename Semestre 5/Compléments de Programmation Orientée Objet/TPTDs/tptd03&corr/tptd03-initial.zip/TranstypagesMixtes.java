public class TranstypagesMixtes {
    public static void main(String[] args) {
        Object vObject = Integer.valueOf(9);
        Integer vInteger = 42;
        int vint = 111;
        System.out.println("vObject = " + vObject + 
            ", vInteger = " + vInteger +
            ", vint = " + vint);
            
    }
}
